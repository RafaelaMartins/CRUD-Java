/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visao;

import exceptions.ExceptionService;
import java.awt.Frame;
import visao.TelaSobre;
import javax.swing.JOptionPane;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.*;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import modelo.Agenda;
import service.AgendaService;

import java.awt.Color;
import java.awt.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import modelo.Atendente;
import modelo.Paciente;

import service.AtendenteService;
import service.PacienteService;


public class TelaAgenda extends javax.swing.JFrame {
 
     Agenda ag = new Agenda();
     AgendaService agService = new AgendaService();  
     
     List<Agenda> ListAgenda = new ArrayList<Agenda>();
     ArrayList<Agenda> ArrayAgenda = new ArrayList<Agenda>();
     
     Paciente pa = new Paciente();
     PacienteService paService = new PacienteService(); 
     
     Atendente at = new Atendente();
     AtendenteService atService = new AtendenteService(); 
     
     String aux_data;
     
     Date dt_consulta;
     Date h_consulta;
     
     String str_at;
     String str_pa;
    /*
    public Agenda() {
        initComponents();
    }
    */
     public TelaAgenda(java.awt.Frame parent, boolean modal) throws ParseException, ExceptionService{
        //super(parent, modal);
        initComponents();
        
        Date hoje = jCalendar2.getDate();
        long hj_h = hoje.getTime();
        
        //System.out.println("hoje="+hoje);
        
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String strDate = formatter.format(hoje);
        
        System.out.println("hoje2="+strDate);
        
        aux_data = new SimpleDateFormat("dd/MM/yyyy").format(jCalendar2.getDate());
        DefaultTableModel tabelaModelo = (DefaultTableModel) jTable1.getModel();
               
        dt_consulta = new SimpleDateFormat("dd/MM/yyyy").parse(aux_data);
        
        /*
        hoje = new SimpleDateFormat("yyyy-MM-dd").parse(strDate);
        
        SimpleDateFormat formatterf = new SimpleDateFormat("yyyy-MM-dd");
        String strDatef = formatterf.format(hoje);
        
        System.out.println("hojef="+strDatef);*/
        
        java.sql.Date dataSql = new java.sql.Date(hoje.getTime());
        
        System.out.println("dtsql"+dataSql);
        
        ListAgenda = agService.getAgendaData(dataSql);
        
        System.out.println("teste1"); 
        
        //DefaultTableModel tabelaModelo = (DefaultTableModel) jTable1.getModel();
        
        System.out.println("teste2"); 
        
        for(Agenda a: ListAgenda)
        {
            
           System.out.println("teste3"); 
            
           SimpleDateFormat formatterh = new SimpleDateFormat("HH:mm");
           String horario = formatterh.format(a.getH_inicio()); 
           
           System.out.println("horario="+horario);
           
           if(horario.equals("8:00"))
           {    
               tabelaModelo.setValueAt(a.getPaciente().getNome(),0,1);
               tabelaModelo.setValueAt(a.getAtendente().getNome(),0,2);              
               tabelaModelo.setValueAt(a.getStatus(),0,3);
           }
           
           if(horario.equals("9:00"))
           {    
               tabelaModelo.setValueAt(a.getPaciente().getNome(),1,1);
               tabelaModelo.setValueAt(a.getAtendente().getNome(),1,2);               
               tabelaModelo.setValueAt(a.getStatus(),1,3);
           }
           
           if(horario.equals("10:00"))
           {    
               tabelaModelo.setValueAt(a.getPaciente().getNome(),2,1);
               tabelaModelo.setValueAt(a.getAtendente().getNome(),2,2);
               tabelaModelo.setValueAt(a.getStatus(),2,3);
           }
           
           if(horario.equals("11:00"))
           {    
               tabelaModelo.setValueAt(a.getPaciente().getNome(),3,1);
               tabelaModelo.setValueAt(a.getAtendente().getNome(),3,2);
               tabelaModelo.setValueAt(a.getStatus(),3,3);
           }
           
           if(horario.equals("12:00"))
           {    
               tabelaModelo.setValueAt(a.getPaciente().getNome(),4,1);
               tabelaModelo.setValueAt(a.getAtendente().getNome(),4,2);
               tabelaModelo.setValueAt(a.getStatus(),4,3);
           }
           
           if(horario.equals("13:00"))
           {    
               tabelaModelo.setValueAt(a.getPaciente().getNome(),5,1);
               tabelaModelo.setValueAt(a.getAtendente().getNome(),5,2);
               tabelaModelo.setValueAt(a.getStatus(),5,3);
           }
           
           if(horario.equals("14:00"))
           {    
               tabelaModelo.setValueAt(a.getPaciente().getNome(),6,1);
               tabelaModelo.setValueAt(a.getAtendente().getNome(),6,2);
               tabelaModelo.setValueAt(a.getStatus(),6,3);
           }
           
           if(horario.equals("15:00"))
           {    
               tabelaModelo.setValueAt(a.getPaciente().getNome(),7,1);
               tabelaModelo.setValueAt(a.getAtendente().getNome(),7,2);
               tabelaModelo.setValueAt(a.getStatus(),7,3);
           }
           
            if(horario.equals("16:00"))
           {    
               tabelaModelo.setValueAt(a.getPaciente().getNome(),8,1);
               tabelaModelo.setValueAt(a.getAtendente().getNome(),8,2);
               tabelaModelo.setValueAt(a.getStatus(),8,3);
           }
           
           if(horario.equals("17:00"))
           {    
               
               System.out.println("testehora"); 
               
               tabelaModelo.setValueAt(a.getPaciente().getNome(),9,1);
               tabelaModelo.setValueAt(a.getAtendente().getNome(),9,2);
               tabelaModelo.setValueAt(a.getStatus(),9,3);
           }
        }
        
        
        
        
        
         jTable1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         
         this.jTable1.setEnabled(true);
                 
        String[] Horas = {"8:00", "9:00", "10:00", "11:00", "12:00", "13:00",
            "14:00", "15:00", "16:00", "17:00"};    
              

        String HoraInicio = "8:00";
        String HoraFinal = "17:00";
        
        jCalendar2.getDayChooser().addPropertyChangeListener("day", new PropertyChangeListener() {

            @Override
            public void propertyChange(PropertyChangeEvent e) {
                aux_data = new SimpleDateFormat("dd/MM/yyyy").format(jCalendar2.getDate());
                DefaultTableModel tabelaModelo = (DefaultTableModel) jTable1.getModel();
                try {
                    dt_consulta = new SimpleDateFormat("dd/MM/yyyy").parse(aux_data);
                    ListAgenda.clear();
                    tabelaModelo.setValueAt("",0,1);
                    tabelaModelo.setValueAt("",0,2);
                    tabelaModelo.setValueAt("",0,3);
                   
                    tabelaModelo.setValueAt("",1,1);
                    tabelaModelo.setValueAt("",1,2);
                    tabelaModelo.setValueAt("",1,3);
                    
                    tabelaModelo.setValueAt("",2,1);
                    tabelaModelo.setValueAt("",2,2);
                    tabelaModelo.setValueAt("",2,3);
                    
                    tabelaModelo.setValueAt("",3,1);
                    tabelaModelo.setValueAt("",3,2);
                    tabelaModelo.setValueAt("",3,3);
                    
                    tabelaModelo.setValueAt("",4,1);
                    tabelaModelo.setValueAt("",4,2);
                    tabelaModelo.setValueAt("",4,3);
                    
                    tabelaModelo.setValueAt("",5,1);
                    tabelaModelo.setValueAt("",5,2);
                    tabelaModelo.setValueAt("",5,3);
                    
                    tabelaModelo.setValueAt("",6,1);
                    tabelaModelo.setValueAt("",6,2);
                    tabelaModelo.setValueAt("",6,3);
                    
                    tabelaModelo.setValueAt("",7,1);
                    tabelaModelo.setValueAt("",7,2);
                    tabelaModelo.setValueAt("",7,3);
                    
                    tabelaModelo.setValueAt("",8,1);
                    tabelaModelo.setValueAt("",8,2);
                    tabelaModelo.setValueAt("",8,3);
                    
                    tabelaModelo.setValueAt("",9,1);
                    tabelaModelo.setValueAt("",9,2);
                    tabelaModelo.setValueAt("",9,3);
                    
                    try {
                        
                        java.sql.Date dataSql = new java.sql.Date(dt_consulta.getTime());
        
                        System.out.println("dtsql"+dataSql);
        
                        ListAgenda = agService.getAgendaData(dataSql);
                        
                        //ListAgenda = agService.getAgendaData(dt_consulta);
                    } catch (ExceptionService ex) {
                        Logger.getLogger(TelaAgenda.class.getName()).log(Level.SEVERE, null, ex);
                    }
        
                    

                    for(Agenda a: ListAgenda)
                    {
                       SimpleDateFormat formatterh = new SimpleDateFormat("HH:mm");
                       String horario = formatterh.format(a.getH_inicio()); 
                       
                        System.out.println("horario="+horario);

                      if(horario.equals("8:00"))
                        {    
                            tabelaModelo.setValueAt(a.getPaciente().getNome(),0,1);
                            tabelaModelo.setValueAt(a.getAtendente().getNome(),0,2);
                            tabelaModelo.setValueAt(a.getStatus(),0,3);
                        }

                        if(horario.equals("9:00"))
                        {    
                            tabelaModelo.setValueAt(a.getPaciente().getNome(),1,1);
                            tabelaModelo.setValueAt(a.getAtendente().getNome(),1,2);
                            tabelaModelo.setValueAt(a.getStatus(),1,3);
                        }

                        if(horario.equals("10:00"))
                        {    
                            tabelaModelo.setValueAt(a.getPaciente().getNome(),2,1);
                            tabelaModelo.setValueAt(a.getAtendente().getNome(),2,2);
                            tabelaModelo.setValueAt(a.getStatus(),2,3);
                        }

                        if(horario.equals("11:00"))
                        {    
                            tabelaModelo.setValueAt(a.getPaciente().getNome(),3,1);
                            tabelaModelo.setValueAt(a.getAtendente().getNome(),3,2);
                            tabelaModelo.setValueAt(a.getStatus(),3,3);
                        }

                        if(horario.equals("12:00"))
                        {    
                            tabelaModelo.setValueAt(a.getPaciente().getNome(),4,1);
                            tabelaModelo.setValueAt(a.getAtendente().getNome(),4,2);
                            tabelaModelo.setValueAt(a.getStatus(),4,3);
                        }

                        if(horario.equals("13:00"))
                        {    
                            tabelaModelo.setValueAt(a.getPaciente().getNome(),5,1);
                            tabelaModelo.setValueAt(a.getAtendente().getNome(),5,2);
                            tabelaModelo.setValueAt(a.getStatus(),5,3);
                        }

                        if(horario.equals("14:00"))
                        {    
                            tabelaModelo.setValueAt(a.getPaciente().getNome(),6,1);
                            tabelaModelo.setValueAt(a.getAtendente().getNome(),6,2);
                            tabelaModelo.setValueAt(a.getStatus(),6,3);
                        }

                        if(horario.equals("15:00"))
                        {    
                            tabelaModelo.setValueAt(a.getPaciente().getNome(),7,1);
                            tabelaModelo.setValueAt(a.getAtendente().getNome(),7,2);
                            tabelaModelo.setValueAt(a.getStatus(),7,3);
                        }

                         if(horario.equals("16:00"))
                        {    
                            tabelaModelo.setValueAt(a.getPaciente().getNome(),8,1);
                            tabelaModelo.setValueAt(a.getAtendente().getNome(),8,2);
                            tabelaModelo.setValueAt(a.getStatus(),8,3);
                        }

                        if(horario.equals("17:00"))
                        {    

                            System.out.println("testehora"); 

                            tabelaModelo.setValueAt(a.getPaciente().getNome(),9,1);
                            tabelaModelo.setValueAt(a.getAtendente().getNome(),9,2);
                            tabelaModelo.setValueAt(a.getStatus(),9,3);
                        }
                    }
                } catch (ParseException ex) {
                    Logger.getLogger(TelaAgenda.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.out.println("data pega="+aux_data);
            }
        });
        
        //pack();
        
        
        

    }
    
    /*
    Agenda(TelaSobre aThis, boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    */
     /*
    Agenda(Agenda agenda, boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    */

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jCalendar2 = new com.toedter.calendar.JCalendar();
        btn_voltaratelainicial = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"8:00", null, null, null, null},
                {"9:00", null, null, null, null},
                {"10:00", null, null, null, null},
                {"11:00", null, null, null, null},
                {"12:00", null, null, null, null},
                {"13:00", "", null, null, null},
                {"14:00", "", null, null, null},
                {"15:00", null, null, null, null},
                {"16:00", null, null, null, null},
                {"17:00", null, null, null, null}
            },
            new String [] {
                "Horário", "Paciente", "Atendente", "Procedimento", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        btn_voltaratelainicial.setText("Voltar a Tela Inicial");
        btn_voltaratelainicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_voltaratelainicialActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/climed.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 614, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jCalendar2, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(52, 52, 52))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_voltaratelainicial)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jCalendar2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_voltaratelainicial))
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(113, 113, 113))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_voltaratelainicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_voltaratelainicialActionPerformed
        // TODO add your handling code here:
        
        TelaSobre telasobre = null;
            try {
                telasobre = new TelaSobre(this, true);
                //System.out.print("valido2 = ");
                //System.out.println(valido);
            } catch (ExceptionService ex) {
                Logger.getLogger(TelaLogin.class.getName()).log(Level.SEVERE, null, ex);
            }
            
          this.setVisible(false);                   
          telasobre.setVisible(true);
    }//GEN-LAST:event_btn_voltaratelainicialActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        System.out.println("entrou pega linha");
        if(evt.getClickCount() == 1)
        { 
            System.out.println("entrou if pega linha");
            Object obj = (jTable1.getValueAt(jTable1.getSelectedRow(), 0));         
            System.out.println("pegou linha");
            String teste_h = obj.toString();
            System.out.println("passou pra string");
            System.out.println("linha hora = "+teste_h);           
                       
            if((jTable1.getValueAt(jTable1.getSelectedRow(), 1))!= null)
            {
                Object obj_pa = (jTable1.getValueAt(jTable1.getSelectedRow(), 1)); 
                
                str_pa = obj_pa.toString();
                
                System.out.println("pegou linha editar");
                String teste = obj_pa.toString();
                System.out.println("passou pra string pa = "+teste);
                /*
                try {
                    pa = paService.getPaciente(str_pa);
                } catch (ExceptionService ex) {
                    Logger.getLogger(TelaAgenda.class.getName()).log(Level.SEVERE, null, ex);
                }
                */
            }
            
            if((jTable1.getValueAt(jTable1.getSelectedRow(), 2))!= null)
            {
                Object obj_at = (jTable1.getValueAt(jTable1.getSelectedRow(), 2));  
                str_at = obj_at.toString();
                
                System.out.println("pegou linha editar");
                String teste = obj_at.toString();
                System.out.println("passou pra string at = "+teste);
               /*
                try {
                    at = atService.getAtendente(str_at);
                } catch (ExceptionService ex) {
                    Logger.getLogger(TelaAgenda.class.getName()).log(Level.SEVERE, null, ex);
                }*/
            }
            
            
            
            try {
                h_consulta = new SimpleDateFormat("HH:mm").parse(teste_h);
            } catch (ParseException ex) {
                Logger.getLogger(TelaAgenda.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            TelaCadastra_Agendamento telacadastra_agendamento = null;
            telacadastra_agendamento = new TelaCadastra_Agendamento(telacadastra_agendamento, true, dt_consulta, h_consulta, str_pa, str_at);
            //this.setVisible(false);
            this.dispose();
            telacadastra_agendamento.setVisible(true);
            
        }
    }//GEN-LAST:event_jTable1MouseClicked
          
           
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaAgenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaAgenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaAgenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaAgenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TelaAgenda dialog = null;
                try {
                    dialog = new TelaAgenda(new javax.swing.JFrame(), true);
                } catch (ParseException ex) {
                    Logger.getLogger(TelaAgenda.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ExceptionService ex) {
                    Logger.getLogger(TelaAgenda.class.getName()).log(Level.SEVERE, null, ex);
                }
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_voltaratelainicial;
    private com.toedter.calendar.JCalendar jCalendar2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
