
package service;

import java.util.List;
import modelo.Agenda;
import classes_dao.AgendaDao;
import exceptions.ExceptionService;
import java.util.Date;
import javax.persistence.EntityManager;
import util.Conexao;

public class AgendaService {
    
    private AgendaDao dao;

    public AgendaService() {
       dao = new AgendaDao();
    }      
        
    public void salvar(Agenda entidade) throws ExceptionService{
        
        if (entidade.getData() == null){
            throw new ExceptionService("Data não informado.");
        
        }
        dao.salvar(entidade);
    }

    public List<Agenda> getAll(){
        return dao.getAll();
    }
    
    public Agenda getAgenda(Integer codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getAgenda(codigo);
    }
    
    
    public Agenda remover(Integer codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Agenda aux = dao.getAgenda(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }
    
    /*
    public List<String> getLista(){    
            
        EntityManager em = Conexao.getConexao();
        
        List<String> nomes = 
           em.createQuery("select f.nome "
                     + "from Atendente f ",
                   String.class)
                       .getResultList();
        
        for (String nome : nomes) {
            System.out.println(nome);
        }
        
        return nomes;
    }
    */
    public List<Agenda> getAgendaData(Date data) throws ExceptionService{
        
        if (data == null){
            throw new ExceptionService("Data não informado.");        
        }
        
        System.out.println("teste01"); 
        
        EntityManager em = Conexao.getConexao();
            
         System.out.println("dt="+data);
        
        String jpql = "select f from Agenda f where f.data = :data";
        
         List<Agenda> consultas  = em.createQuery(jpql,Agenda.class)                   
                  .setParameter("data", data)
                 .getResultList();
         
         System.out.println("testeR"); 
         
         Agenda ag = new Agenda();
         
         for(Agenda c : consultas){
              System.out.println("testesss"); 
              ag = c;
         } 
         
        System.out.println("teste0"); 
         
         return consultas; 
    }
    
}
