
package service;

import java.util.List;
import modelo.Logradouro;
import classes_dao.LogradouroDao;
import exceptions.ExceptionService;

public class LogradouroService {
    
    private LogradouroDao dao;

    public LogradouroService() {
       dao = new LogradouroDao();
    }
    
        
    public void salvar(Logradouro entidade) throws ExceptionService{
        
        if (entidade.getNome() == null || 
                entidade.getNome().isEmpty()){
            throw new ExceptionService("Nome não informado.");
        
        }
        dao.salvar(entidade);
    }

    public List<Logradouro> getAll(){
        return dao.getAll();
    }
    
    public Logradouro getLogradouro(Long codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getLogradouro(codigo);
    }
    
    
    public Logradouro remover(Long codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Logradouro aux = dao.getLogradouro(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }
    
}
