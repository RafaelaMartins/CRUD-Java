
package service;

import java.util.List;
import modelo.Procedimento;
import classes_dao.ProcedimentoDao;
import exceptions.ExceptionService;
import javax.persistence.EntityManager;
import util.Conexao;

public class ProcedimentoService {
    
    private ProcedimentoDao dao;

    public ProcedimentoService() {
       dao = new ProcedimentoDao();
    }
    
    
    
    
    public void salvar(Procedimento entidade) throws ExceptionService{
        
        if (entidade.getNome() == null || 
                entidade.getNome().isEmpty()){
            throw new ExceptionService("Nome não informado.");
        
        }
        dao.salvar(entidade);
    }

    public List<Procedimento> getAll(){
        return dao.getAll();
    }
    
    public Procedimento getProcedimento(Integer codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getProcedimento(codigo);
    }
    
    
    public Procedimento remover(Integer codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Procedimento aux = dao.getProcedimento(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }

    public List<String> getLista(){    
            
        EntityManager em = Conexao.getConexao();
        
        List<String> nomes = 
           em.createQuery("select f.nome "
                     + "from Procedimento f ",
                   String.class)
                       .getResultList();
        
        for (String nome : nomes) {
            System.out.println(nome);
        }
        
        return nomes;
    }
    
    public Procedimento getProcedimento(String nome) throws ExceptionService{
        
        if (nome == null){
            throw new ExceptionService("Procedimento não informado.");        
        }
        
        EntityManager em = Conexao.getConexao();
              
        
        String jpql = "select f from Procedimento f where f.nome like :nome";
        
         List<Procedimento> prods  = em.createQuery(jpql,Procedimento.class)                   
                  .setParameter("nome", nome+"%")
                 .getResultList();
         
         Procedimento pp = new Procedimento();
         
         for(Procedimento p : prods){
              pp = p;
         } 
         
         return pp; 
    }
    
}
