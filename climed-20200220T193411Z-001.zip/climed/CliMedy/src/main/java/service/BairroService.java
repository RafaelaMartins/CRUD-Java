
package service;

import java.util.List;
import modelo.Bairro;
import classes_dao.BairroDao;
import exceptions.ExceptionService;

public class BairroService {
    
    private BairroDao dao;

    public BairroService() {
       dao = new BairroDao();
    }  
       
    
    public void salvar(Bairro entidade) throws ExceptionService{
        
        if (entidade.getNome() == null || 
                entidade.getNome().isEmpty()){
            throw new ExceptionService("Nome não informado.");
        
        }
        dao.salvar(entidade);
    }

    public List<Bairro> getAll(){
        return dao.getAll();
    }
    
    public Bairro getBairro(Long codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getBairro(codigo);
    }
    
    
    public Bairro remover(Long codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Bairro aux = dao.getBairro(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }
    
}
