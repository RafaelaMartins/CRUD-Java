
package service;

import java.util.List;
import modelo.Agenda;
import classes_dao.AgendaDao;
import exceptions.ExceptionService;
import java.util.Date;
import javax.persistence.EntityManager;
import util.Conexao;

public class AgendaService {
    
    private AgendaDao dao;

    public AgendaService() {
       dao = new AgendaDao();
    }      
        
    public void salvar(Agenda entidade) throws ExceptionService{
        
        if (entidade.getData() == null){
            throw new ExceptionService("Data não informado.");
        
        }
        dao.salvar(entidade);
    }

    public List<Agenda> getAll(){
        return dao.getAll();
    }
    
    public Agenda getAgenda(Integer codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getAgenda(codigo);
    }
    
    
    public Agenda remover(Integer codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Agenda aux = dao.getAgenda(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }
    
    /*
    public List<String> getLista(){    
            
        EntityManager em = Conexao.getConexao();
        
        List<String> nomes = 
           em.createQuery("select f.nome "
                     + "from Atendente f ",
                   String.class)
                       .getResultList();
        
        for (String nome : nomes) {
            System.out.println(nome);
        }
        
        return nomes;
    }
    */
    public Agenda getAgendaData(Date data) throws ExceptionService{
        
        if (data == null){
            throw new ExceptionService("Data não informado.");        
        }
        
        EntityManager em = Conexao.getConexao();
              
        
        String jpql = "select f from Agenda f where f.data = :data";
        
         List<Agenda> consultas  = em.createQuery(jpql,Agenda.class)                   
                  .setParameter("data", data+"%")
                 .getResultList();
         
         Agenda ag = new Agenda();
         
         for(Agenda c : consultas){
              ag = c;
         } 
         
         return ag; 
    }
    
}
