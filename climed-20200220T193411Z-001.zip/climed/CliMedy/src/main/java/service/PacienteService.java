
package service;

import classes_dao.AtendenteDao;
import classes_dao.PacienteDao;
import exceptions.ExceptionService;
import java.util.List;
import javax.persistence.EntityManager;
import modelo.Paciente;
import util.Conexao;

public class PacienteService {
    
    private PacienteDao pDAO;
    
    
    public PacienteService() {        
        pDAO = new PacienteDao();
    }
    
     public List<Paciente> getAll(){
        return pDAO.getAll();
    }
 
      public Paciente buscarPorID(Integer id) throws ExceptionService {
          
        if (id == null || id <=0 )  
          throw new ExceptionService("Informe um código válido.");
        
        return pDAO.buscarPorID(id);
    }

    public void salvar(Paciente entidade) throws ExceptionService {
        
        //Na insersão verificamos se o login está disponivel.
        /*
        if (entidade.getCodigo()== null){
           throw new ExceptionService("Login já cadastrado.");
        }
        */
        pDAO.salvar(entidade);
    }

    public boolean remover(Integer id) throws ExceptionService {
        
        if (id == null || id <= 0 )
         throw new ExceptionService("Dados não informados.");

        
        return pDAO.isremover(id);
    }

    public List<Paciente> buscarTodos() {
        return pDAO.buscarTodas();
    }
    
    public Boolean loginValido(String login, String senha) throws ExceptionService{
        
        if (login == null || senha == null)
          throw new ExceptionService("Informe o nome e senha do usuário");
        
        
        if (login.trim().equals("") || senha.trim().equals(""))
          throw new ExceptionService("Informe o nome e senha do usuário");
        
        return pDAO.isValidLogin(login, senha);                
    } 
    
    public List<String> getLista(){    
            
        EntityManager em = Conexao.getConexao();
        
        List<String> nomes = 
           em.createQuery("select f.nome "
                     + "from Paciente f ",
                   String.class)
                       .getResultList();
        
        for (String nome : nomes) {
            System.out.println(nome);
        }
        
        return nomes;
    }
    
    public Paciente getPaciente(String nome) throws ExceptionService{
        
        if (nome == null){
            throw new ExceptionService("Paciente não informado.");        
        }
        
        EntityManager em = Conexao.getConexao();
              
        
        String jpql = "select f from Paciente f where f.nome like :nome";
        
         List<Paciente> prods  = em.createQuery(jpql,Paciente.class)                   
                  .setParameter("nome", nome+"%")
                 .getResultList();
         
         Paciente pp = new Paciente();
         
         for(Paciente p : prods){
              pp = p;
         } 
         
         return pp; 
    }
    
}
