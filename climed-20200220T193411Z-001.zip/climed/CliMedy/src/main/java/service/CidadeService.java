
package service;

import java.util.List;
import modelo.Cidade;
import classes_dao.CidadeDao;
import exceptions.ExceptionService;

public class CidadeService {
    
    private CidadeDao dao;

    public CidadeService() {
       dao = new CidadeDao();
    }
    
        
    public void salvar(Cidade entidade) throws ExceptionService{
        
        if (entidade.getNome() == null || 
                entidade.getNome().isEmpty()){
            throw new ExceptionService("Nome não informado.");
        
        }
        dao.salvar(entidade);
    }

    public List<Cidade> getAll(){
        return dao.getAll();
    }
    
    public Cidade getCidade(Long codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getCidade(codigo);
    }
    
    
    public Cidade remover(Long codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Cidade aux = dao.getCidade(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }
    
}
