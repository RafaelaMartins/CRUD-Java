
package service;

import java.util.List;
import modelo.Cargo;
import classes_dao.CargoDao;
import exceptions.ExceptionService;

public class CargoService {
    
    private CargoDao dao;

    public CargoService() {
       dao = new CargoDao();
    }
    
    
    public void salvar(Cargo entidade) throws ExceptionService{
        
        if (entidade.getNome() == null || 
                entidade.getNome().isEmpty()){
            throw new ExceptionService("Nome não informado.");
        
        }
        dao.salvar(entidade);
    }

    public List<Cargo> getAll(){
        return dao.getAll();
    }
    
    public Cargo getCargo(Long codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getCargo(codigo);
    }
    
    
    public Cargo remover(Long codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Cargo aux = dao.getCargo(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }
    
}
