
package service;

import java.util.List;
import modelo.Empresa;
import classes_dao.EmpresaDao;
import exceptions.ExceptionService;

public class EmpresaService {
    
    private EmpresaDao dao;

    public EmpresaService() {
       dao = new EmpresaDao();
    }       
    
    public void salvar(Empresa entidade) throws ExceptionService{
        
        if (entidade.getRasaoSocial() == null || 
                entidade.getRasaoSocial().isEmpty()){
            throw new ExceptionService("Nome não informado.");
        
        }
        dao.salvar(entidade);
    }

    public List<Empresa> getAll(){
        return dao.getAll();
    }
    
    public Empresa getEmpresa(Integer codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getEmpresa(codigo);
    }
    
    
    public Empresa remover(Integer codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Empresa aux = dao.getEmpresa(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }
    
}
