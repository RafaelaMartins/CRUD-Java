/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.util.List;
import modelo.Equipamento;
import classes_dao.EquipamentoDao;
import exceptions.ExceptionService;
import javax.persistence.EntityManager;
import util.Conexao;

public class EquipamentoService {
    
    private EquipamentoDao dao;

    public EquipamentoService() {
       dao = new EquipamentoDao();
    }
     
        
    public void salvar(Equipamento entidade) throws ExceptionService{
        
        if (entidade.getNome() == null || 
                entidade.getNome().isEmpty()){
            throw new ExceptionService("Nome não informado.");
        
        }
        dao.salvar(entidade);
    }

    public List<Equipamento> getAll(){
        return dao.getAll();
    }
    
    public Equipamento getEquipamento(Integer codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getEquipamento(codigo);
    }
    
    
    public Equipamento remover(Integer codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Equipamento aux = dao.getEquipamento(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }
    
    public List<String> getLista(){    
            
        EntityManager em = Conexao.getConexao();
        
        List<String> nomes = 
           em.createQuery("select f.nome "
                     + "from Equipamento f ",
                   String.class)
                       .getResultList();
        
        for (String nome : nomes) {
            System.out.println(nome);
        }
        
        return nomes;
    } 
    
     public Equipamento getEquipamento(String nome) throws ExceptionService{
        
        if (nome == null){
            throw new ExceptionService("Equipamento não informado.");        
        }
        
        EntityManager em = Conexao.getConexao();
              
        
        String jpql = "select f from Equipamento f where f.nome like :nome";
        
         List<Equipamento> eqps  = em.createQuery(jpql,Equipamento.class)                   
                  .setParameter("nome", nome+"%")
                 .getResultList();
         
         Equipamento eq = new Equipamento();
         
         for(Equipamento q : eqps){
              eq = q;
         } 
         
         return eq; 
    }
    
}
