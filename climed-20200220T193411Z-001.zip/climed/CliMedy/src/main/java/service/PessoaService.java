
package service;

import java.util.List;
import classes_dao.PessoaDao;
import modelo.Pessoa;
import exceptions.ExceptionService;
import modelo.Paciente;

public class PessoaService {
    
    private PessoaDao dao;

    public PessoaService() {
       dao = new PessoaDao();
    }       
    
    public void salvar(Pessoa entidade) throws ExceptionService{
        
        if (entidade.getNome()== null || 
                entidade.getNome().isEmpty()){
            throw new ExceptionService("Nome não informado.");
        
        }
        
        if (entidade.getCpf()== null){
            throw new ExceptionService("CPF não informado.");        
        }
        
        
        dao.salvar(entidade);
    }

    public List<Pessoa> getAll(){
        return dao.getAll();
    }
    
    public Pessoa getPessoa(Long codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getPessoa(codigo);
    }
    
    
    public Pessoa remover(Long codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Pessoa aux = dao.getPessoa(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }
    
     public List<Pessoa> buscarTodos() {
        return dao.buscarTodas();
    }
     
     public Pessoa buscarPorID(Integer id) throws ExceptionService {
          
        if (id == null || id <=0 )  
          throw new ExceptionService("Informe um código válido.");
        
        return dao.buscarPorID(id);
    }
    
    public Boolean loginValido(String login, String senha) throws ExceptionService{
        
        if (login == null || senha == null)
          throw new ExceptionService("Informe o nome e senha do usuário");
        
        
        if (login.trim().equals("") || senha.trim().equals(""))
          throw new ExceptionService("Informe o nome e senha do usuário");
        
        System.out.println(login);
          System.out.println(senha);
        
        return dao.isValidLogin(login, senha);                
    }
    
}
