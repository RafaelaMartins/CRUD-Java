
package service;

import java.util.List;
import modelo.Produto;
import classes_dao.ProdutoDao;
import exceptions.ExceptionService;
import javax.persistence.EntityManager;
import util.Conexao;

public class ProdutoService {
    
    private ProdutoDao dao;

    public ProdutoService() {
       dao = new ProdutoDao();
    }
    
    
    
    
    public void salvar(Produto entidade) throws ExceptionService{
        
        if (entidade.getNome() == null || 
                entidade.getNome().isEmpty()){
            throw new ExceptionService("Nome não informado.");
        
        }
        dao.salvar(entidade);
    }

    public List<Produto> getAll(){
        return dao.getAll();
    }
    
    public Produto getProduto(Integer codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getProduto(codigo);
    }
    
    
    public Produto remover(Integer codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Produto aux = dao.getProduto(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }
    
    public List<String> getLista(){    
            
        EntityManager em = Conexao.getConexao();
        
        List<String> nomes = 
           em.createQuery("select f.nome "
                     + "from Produto f ",
                   String.class)
                       .getResultList();
        
        for (String nome : nomes) {
            System.out.println(nome);
        }
        
        return nomes;
    }
    
    public Produto getProduto(String nome) throws ExceptionService{
        
        if (nome == null){
            throw new ExceptionService("Produto não informado.");        
        }
        
        EntityManager em = Conexao.getConexao();
              
        
        String jpql = "select f from Produto f where f.nome like :nome";
        
         List<Produto> prods  = em.createQuery(jpql,Produto.class)                   
                  .setParameter("nome", nome+"%")
                 .getResultList();
         
         Produto pp = new Produto();
         
         for(Produto p : prods){
              pp = p;
         } 
         
         return pp; 
    }
    
}
