
package service;

import java.util.List;
import modelo.Formacao;
import classes_dao.FormacaoDao;
import exceptions.ExceptionService;

public class FormacaoService {
    
    private FormacaoDao dao;

    public FormacaoService() {
       dao = new FormacaoDao();
    }
    
        
    public void salvar(Formacao entidade) throws ExceptionService{
        
        if (entidade.getCurso() == null || 
                entidade.getCurso().isEmpty()){
            throw new ExceptionService("Curso não informado.");
        
        }
        dao.salvar(entidade);
    }

    public List<Formacao> getAll(){
        return dao.getAll();
    }
    
    public Formacao getFormacao(Long codigo) throws ExceptionService{
        
        if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        
        }
        
        return dao.getFormacao(codigo);
    }
    
    
    public Formacao remover(Long codigo) throws ExceptionService{
        
       if (codigo == null || 
                codigo <= 0 ){
            throw new ExceptionService("Código não informado.");
        }
        
       Formacao aux = dao.getFormacao(codigo);
       if (aux == null){
            throw new ExceptionService("Código inválido.");
        }
              
        return dao.remover(codigo);
    }
    
}
