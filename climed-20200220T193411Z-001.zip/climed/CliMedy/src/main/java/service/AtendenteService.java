
package service;

import java.util.List;
import javax.persistence.EntityManager;
import java.util.List;
import javax.persistence.NoResultException;
import util.Conexao;
import modelo.Atendente;
import classes_dao.AtendenteDao;
import exceptions.ExceptionService;

public class AtendenteService {
    
    private AtendenteDao aDAO;
    
    
    public AtendenteService() {        
        aDAO = new AtendenteDao();
    }
    
     public List<Atendente> getAll(){
        return aDAO.getAll();
    }
 
      public Atendente buscarPorID(Integer id) throws ExceptionService {
          
        if (id == null || id <=0 )  
          throw new ExceptionService("Informe um código válido.");
        
        return aDAO.buscarPorID(id);
    }
      
     public List<String> getLista(){    
            
        EntityManager em = Conexao.getConexao();
        
        List<String> nomes = 
           em.createQuery("select f.nome "
                     + "from Atendente f ",
                   String.class)
                       .getResultList();
        
        for (String nome : nomes) {
            System.out.println(nome);
        }
        
        return nomes;
    }
    
    public Atendente getAtendente(String nome) throws ExceptionService{
        
        if (nome == null){
            throw new ExceptionService("Atendente não informado.");        
        }
        
        EntityManager em = Conexao.getConexao();
              
        
        String jpql = "select f from Atendente f where f.nome like :nome";
        
         List<Atendente> prods  = em.createQuery(jpql,Atendente.class)                   
                  .setParameter("nome", nome+"%")
                 .getResultList();
         
         Atendente pp = new Atendente();
         
         for(Atendente p : prods){
              pp = p;
         } 
         
         return pp; 
    }

    public void salvar(Atendente entidade) throws ExceptionService {
        
        //Na insersão verificamos se o login está disponivel.
        /*
        if (entidade.getCodigo()== null &&(!aDAO.isValidLogin(entidade.getLogin()))){
           throw new ExceptionService("Login já cadastrado.");
        }
        */
        aDAO.salvar(entidade);
    }

    public boolean remover(Integer id) throws ExceptionService {
        
        if (id == null || id <= 0 )
         throw new ExceptionService("Dados não informados.");

        
        return aDAO.isremover(id);
    }

    public List<Atendente> buscarTodos() {
        return aDAO.buscarTodas();
    }
    
    public Boolean loginValido(String login, String senha) throws ExceptionService{
        
        System.out.println();
        System.out.println("service");
        System.out.println();
        System.out.println(login);
        System.out.println();
        System.out.println(senha);
        System.out.println();
        
        if (login == null || senha == null)
          throw new ExceptionService("Informe o nome e senha do usuário");
        
        
        if (login.trim().equals("") || senha.trim().equals(""))
          throw new ExceptionService("Informe o nome e senha do usuário");
        
        return aDAO.isValidLogin(login, senha);                
    } 
    
    
    
}
