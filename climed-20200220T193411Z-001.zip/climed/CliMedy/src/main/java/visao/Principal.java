package visao;

import exceptions.ExceptionService;
import java.awt.BorderLayout;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.TemporalType;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import modelo.Administrador;
import modelo.Agenda;
import modelo.Atendente;
import modelo.Bairro;
import modelo.Cargo;
import modelo.Cidade;
import modelo.Empresa;
import modelo.Equipamento;
import modelo.Formacao;
import modelo.Logradouro;
import modelo.Paciente;
import modelo.Pessoa;
import modelo.Procedimento;
import modelo.Produto;
import modelo.Sexo;
import modelo.Atendente;
import modelo.Paciente;

import service.AgendaService;
import service.BairroService;
import service.CargoService;
import service.CidadeService;
import service.EmpresaService;
import service.EquipamentoService;
import service.FormacaoService;
import service.LogradouroService;
import service.PessoaService;
import service.ProcedimentoService;
import service.ProdutoService;
import service.AtendenteService;
import service.PacienteService;

import util.Conexao;
import util.ValidaCPF;

import visao.TelaSobre;
import visao.TelaLogin;
import visao.TelaPrincipal;

public class Principal {
        
    public static void main(String[] args) {       
        
        /* 
        JFrame frame = new JFrame();
        frame.add(telalogin);
        
        JFrame f = new JFrame();
        f.setLayout(new BorderLayout());
        f.add(telalogin,BorderLayout.CENTER);
        f.pack();
        f.setVisible(true);
        
        frame.dispose();     
        */   
        
        ValidaCPF validacpf = new ValidaCPF();
               
        //Declarando e criando os serviços das entidades
        EmpresaService empService = new EmpresaService();        
        PessoaService pesService = new PessoaService();
        ProdutoService prodService = new ProdutoService();
        EquipamentoService eqService = new EquipamentoService();
        ProcedimentoService procService =  new ProcedimentoService(); 
        LogradouroService logService = new LogradouroService();        
        BairroService bService = new BairroService();
        CidadeService cidService = new CidadeService();
        CargoService cargoService = new CargoService();
        FormacaoService formService =  new FormacaoService();
        AgendaService agService = new AgendaService();
        AtendenteService atService = new AtendenteService();
        PacienteService pacService = new PacienteService();
        
        //criando um obj de cada classe;
        Empresa emp = new Empresa();
        Produto prod = new Produto();
        Equipamento eq = new Equipamento();
        Procedimento proc =  new Procedimento(); 
        Logradouro log = new Logradouro();        
        Bairro b = new Bairro();
        Cidade cid = new Cidade();
        Cargo cargo = new Cargo();
        Formacao form =  new Formacao();
        Agenda ag = new Agenda();  
        Paciente paciente = new Paciente();
        Atendente atendente = new Atendente();
        Administrador adm = new Administrador();  
        Atendente atend = new Atendente();
        Paciente pac = new Paciente();
       
        
        //              CONSULTAS
        
        //EntityManager em = Conexao.getConexao();
        
        //Empresa aux_emp = new Empresa();
        
        //List<Empresa> list_emp = em.createQuery("select e from Empresa e where e.codigo =1",Empresa.class).getResultList();
        
        /*
        for(Empresa aux_emp : list_emp)
        {
            TelaSobre.jPanel1.te_razaosocial.setText();
        }
        */
        // ===================================================================================
        
        //cadastrando atendente  ->   Usuario Suporte   
        
        atend.setCodigo(1);
        atend.setNome("Rafaela Suena IFMG");
        atend.setLogin("root");
        atend.setSenha("root");            
        
        String cpf = "01658007638";
        if(validacpf.isCPF(cpf))
        {            
            atend.setCpf(cpf);
            try {
                atService.salvar(atend);
            } catch (ExceptionService ex) {
                JOptionPane.showMessageDialog(null,ex.getMessage());
            }
        }
        
        //======================================================================================
        
        //**********************************************************************************
        
        //cadastrando empresa
        emp.setCodigo(1);        
        emp.setNomeFantasia("BeHealthy");
        emp.setRasaoSocial("Clinica Medica Ltda");
        emp.setTelefone("3733213322");//(37)3321-3322
        emp.setIe("2786772595043");//278.677.259/5043
        emp.setCnpj("89623140000120");//89.623.140/0001-20     
        emp.setContato("www.BeHealthy.com.br");
        emp.setEndereco("Rua Padre Alberico, 440 - São Luiz, Formiga MG");
        //emp.setAdm(adm);
        
        try {
            empService.salvar(emp);
        } catch (ExceptionService ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }
        
        //**********************************************************************************
        
        TelaLogin telalogin = new TelaLogin();        
        telalogin.setVisible(true);
        
        //TelaSobre telasobre = null;
        //telasobre = new TelaSobre(telasobre, true);
    }
}
