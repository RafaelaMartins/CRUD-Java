
package classes_dao;

import javax.persistence.EntityManager;
import java.util.List;
import javax.persistence.NoResultException;
import util.Conexao;
import modelo.Paciente;

public class PacienteDao {
    
    
    private EntityManager em;

    public PacienteDao() {
       em = Conexao.getConexao();
    }
    
    
    public void salvar(Paciente entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Paciente> getAll(){
        return em.createQuery("Select f from Paciente f",Paciente.class)
                .getResultList();
    }
    
    public Paciente getAtendente(Integer codigo){
        return em.find(Paciente.class, codigo);
    }
    
    
    public Paciente remover(Integer codigo){
        
        Paciente aux = getAtendente(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }   
    
     
     public boolean isremover(int id) {
        
        Paciente aux = buscarPorID(id);
        
        if (aux != null){        
          em.getTransaction().begin();
          em.remove(aux);
          em.getTransaction().commit();
          return true;
        }
        return false;        
    }

    
    public Paciente buscarPorID(int id) {       
        
        return em.find(Paciente.class, id);
    }

    
    public List<Paciente> buscarTodas() {
        
        String jpql = "select e from "
                   + Paciente.class.getName()+" e ";
        return
            em.createQuery(jpql).getResultList();
    }    
   
    
     public boolean isValidLogin(String login, String senha){
       
       String jpql = "Select f from Paciente f where "
               + "(f.login = :l) and (f.senha = :s) ";
       
       Paciente aux = null;
               
        try{   
            aux =
               em.createQuery(jpql,Paciente.class)
                  .setParameter("l", login)
                  .setParameter("s", senha)
                  .getSingleResult();
        }
        catch (NoResultException ex){
            aux = null;
        }
       if (aux != null)
           return true;
       else 
           return false;      
   }
    

   public boolean isValidLogin(String login){
       
       String jpql = "Select f from Funcionario f where "
               + "(f.login = :l)";
       List <Paciente> list = em.createQuery(jpql,Paciente.class)
                  .setParameter("l", login)
                  .getResultList();
  
       if (list == null)
         return true;  
       //if (list != null && list.size()==0)
       //  return true;
       
       return false;     
   }
}
