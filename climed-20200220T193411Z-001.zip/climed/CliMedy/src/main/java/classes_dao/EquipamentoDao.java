
package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Equipamento;
import util.Conexao;

public class EquipamentoDao {
    
    private EntityManager em;

    public EquipamentoDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Equipamento entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Equipamento> getAll(){
        return em.createQuery("Select f from Equipamento f",Equipamento.class)
                .getResultList();
    }
    
    public Equipamento getEquipamento(Integer codigo){
        return em.find(Equipamento.class, codigo);
    }
    
    
    public Equipamento remover(Integer codigo){
        
        Equipamento aux = getEquipamento(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
}
