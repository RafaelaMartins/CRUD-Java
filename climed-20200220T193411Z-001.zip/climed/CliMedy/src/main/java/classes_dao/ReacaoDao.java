/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Reacao;
import util.Conexao;

/**
 *
 * @author Suena
 */
public class ReacaoDao {
    
     private EntityManager em;

    public ReacaoDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Reacao entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Reacao> getAll(){
        return em.createQuery("Select f from Reacao f",Reacao.class)
                .getResultList();
    }
    
    public Reacao getReacao(Integer codigo){
        return em.find(Reacao.class, codigo);
    }
    
    
    public Reacao remover(Integer codigo){
        
        Reacao aux = getReacao(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
}
