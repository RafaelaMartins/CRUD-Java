package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Alergia;
import util.Conexao;

public class AlergiaDao {
    
     private EntityManager em;

    public AlergiaDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Alergia entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Alergia> getAll(){
        return em.createQuery("Select f from Alergia f",Alergia.class)
                .getResultList();
    }
    
    public Alergia getAlergia(Integer codigo){
        return em.find(Alergia.class, codigo);
    }
    
    
    public Alergia remover(Integer codigo){
        
        Alergia aux = getAlergia(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
}
