
package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Logradouro;
import util.Conexao;

public class LogradouroDao {
    
    private EntityManager em;

    public LogradouroDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Logradouro entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Logradouro> getAll(){
        return em.createQuery("Select f from Logradouro f",Logradouro.class)
                .getResultList();
    }
    
    public Logradouro getLogradouro(Long codigo){
        return em.find(Logradouro.class, codigo);
    }
    
    
    public Logradouro remover(Long codigo){
        
        Logradouro aux = getLogradouro(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
}
