package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Composto;
import util.Conexao;

public class CompostoDao {
    
     private EntityManager em;

    public CompostoDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Composto entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Composto> getAll(){
        return em.createQuery("Select f from Composto f",Composto.class)
                .getResultList();
    }
    
    public Composto getComposto(Integer codigo){
        return em.find(Composto.class, codigo);
    }
    
    
    public Composto remover(Integer codigo){
        
        Composto aux = getComposto(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
}
