
package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Cargo;
import util.Conexao;

public class CargoDao {
    
    private EntityManager em;

    public CargoDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Cargo entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Cargo> getAll(){
        return em.createQuery("Select f from Cargo f",Cargo.class)
                .getResultList();
    }
    
    public Cargo getCargo(Long codigo){
        return em.find(Cargo.class, codigo);
    }
    
    
    public Cargo remover(Long codigo){
        
        Cargo aux = getCargo(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
}
