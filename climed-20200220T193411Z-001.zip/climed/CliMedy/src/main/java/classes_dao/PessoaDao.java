
package classes_dao;

import javax.persistence.EntityManager;
import java.util.List;
import javax.persistence.NoResultException;
import modelo.Paciente;
import util.Conexao;
import modelo.Pessoa;

public class PessoaDao {
    
    private EntityManager em;

    public PessoaDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Pessoa entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Pessoa> getAll(){
        return em.createQuery("Select f from Pessoa f",Pessoa.class)
                .getResultList();
    }
    
    public Pessoa getPessoa(Long codigo){
        return em.find(Pessoa.class, codigo);
    }
    
    
    public Pessoa remover(Long codigo){
        
        Pessoa aux = getPessoa(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
    public boolean isremover(int id) {
        
        Pessoa aux = buscarPorID(id);
        
        if (aux != null){        
          em.getTransaction().begin();
          em.remove(aux);
          em.getTransaction().commit();
          return true;
        }
        return false;        
    }

    
    public Pessoa buscarPorID(int id) {       
        
        return em.find(Pessoa.class, id);
    }

    
    public List<Pessoa> buscarTodas() {
        
        String jpql = "select e from "
                   + Pessoa.class.getName()+" e ";
        return
            em.createQuery(jpql).getResultList();
    }
    
     public boolean isValidLogin(String login, String senha){
         
          System.out.println(login);
          System.out.println(senha);
       
       String jpql = "Select p FROM Pessoa p WHERE "
               + "(p.login = :l) and (p.senha = :s) ";
       
       Pessoa aux = null;
               
        try{   
            aux =
               em.createQuery(jpql,Pessoa.class)
                  .setParameter("l", login)
                  .setParameter("s", senha)
                  .getSingleResult();
        }
        catch (NoResultException ex){
            aux = null;
        }
       if (aux != null)
           return true;
       else 
           return false;      
   }
     
   public boolean isValidLogin(String login){
       
       String jpql = "Select p from Pessoa p where "
               + "(p.login = :l)";
       List <Pessoa> list = em.createQuery(jpql,Pessoa.class)
                  .setParameter("l", login)
                  .getResultList();
  
       if (list == null)
         return true;  
       //if (list != null && list.size()==0)
       //  return true;
       
       return false;     
   }
    
}
