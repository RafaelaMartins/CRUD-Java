
package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Procedimento;
import util.Conexao;

public class ProcedimentoDao {
    
    private EntityManager em;

    public ProcedimentoDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Procedimento entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Procedimento> getAll(){
        return em.createQuery("Select f from Procedimento f",Procedimento.class)
                .getResultList();
    }
    
    public Procedimento getProcedimento(Integer codigo){
        return em.find(Procedimento.class, codigo);
    }
    
    
    public Procedimento remover(Integer codigo){
        
        Procedimento aux = getProcedimento(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
}
