
package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Agenda;
import util.Conexao;

public class AgendaDao {
   
    private EntityManager em;

    public AgendaDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Agenda entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Agenda> getAll(){
        return em.createQuery("Select f from Agenda f",Agenda.class)
                .getResultList();
    }
    
    public Agenda getAgenda(Integer codigo){
        return em.find(Agenda.class, codigo);
    }
    
    
    public Agenda remover(Integer codigo){
        
        Agenda aux = getAgenda(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
}
