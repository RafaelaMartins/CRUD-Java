
package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Produto;
import util.Conexao;

public class ProdutoDao {
    
    private EntityManager em;

    public ProdutoDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Produto entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Produto> getAll(){
        return em.createQuery("Select f from Produto f",Produto.class)
                .getResultList();
    }
    
    public Produto getProduto(Integer codigo){
        return em.find(Produto.class, codigo);
    }
    
    
    public Produto remover(Integer codigo){
        
        Produto aux = getProduto(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
}
