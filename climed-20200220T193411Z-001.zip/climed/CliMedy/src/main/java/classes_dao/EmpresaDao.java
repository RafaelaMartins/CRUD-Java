
package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Empresa;
import util.Conexao;

public class EmpresaDao {
    
    private EntityManager em;

    public EmpresaDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Empresa entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Empresa> getAll(){
        return em.createQuery("Select f from Empresa f",Empresa.class)
                .getResultList();
    }
    
    public Empresa getEmpresa(Integer codigo){
        return em.find(Empresa.class, codigo);
    }
    
    
    public Empresa remover(Integer codigo){
        
        Empresa aux = getEmpresa(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
}
