
package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Cidade;
import util.Conexao;

public class CidadeDao {
    
    private EntityManager em;

    public CidadeDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Cidade entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Cidade> getAll(){
        return em.createQuery("Select f from Cidade f",Cidade.class)
                .getResultList();
    }
    
    public Cidade getCidade(Long codigo){
        return em.find(Cidade.class, codigo);
    }
    
    
    public Cidade remover(Long codigo){
        
        Cidade aux = getCidade(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
}
