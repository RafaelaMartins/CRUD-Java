
package classes_dao;

import java.lang.reflect.ParameterizedType;
import javax.persistence.EntityManager;
import java.util.List;
import javax.persistence.NoResultException;
import util.Conexao;
import modelo.Atendente;
import modelo.Pessoa;
import util.Conexao;

public class AtendenteDao {
    
    private EntityManager em;

    public AtendenteDao() {
       em = Conexao.getConexao();
    }
    
    
    public void salvar(Atendente entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Atendente> getAll(){
        return em.createQuery("Select f from Atendente f",Atendente.class)
                .getResultList();
    }
    
    public Atendente getAtendente(Integer codigo){
        return em.find(Atendente.class, codigo);
    }
    
    
    public Atendente remover(Integer codigo){
        
        Atendente aux = getAtendente(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }   
    
     
     public boolean isremover(int id) {
        
        Atendente aux = buscarPorID(id);
        
        if (aux != null){        
          em.getTransaction().begin();
          em.remove(aux);
          em.getTransaction().commit();
          return true;
        }
        return false;        
    }

    
    public Atendente buscarPorID(int id) {       
        
        return em.find(Atendente.class, id);
    }
    
    /*
    public Atendente buscarPorNome(String nome) {       
        
        return em.find(Atendente.class, nome);
    }
    */
    
    public List<Atendente> buscarTodas() {
        
        String jpql = "select e from "
                   + Atendente.class.getName()+" e ";
        return
            em.createQuery(jpql).getResultList();
    }    
   
    
     public boolean isValidLogin(String login, String senha){
         
        System.out.println();
        System.out.println("dao");
        System.out.println();
        System.out.println(login);
        System.out.println();
        System.out.println(senha);
        System.out.println();
       
       String jpql = "Select f from Atendente f where "
               + "(f.login = :l) and (f.senha = :s) ";
       
       Atendente aux = null;
               
        try{   
            aux =
               em.createQuery(jpql,Atendente.class)
                  .setParameter("l", login)
                  .setParameter("s", senha)
                  .getSingleResult();
        }
        catch (NoResultException ex){
            aux = null;
        }
       if (aux != null)
           return true;
       else 
           return false;      
   }
    

   public boolean isValidLogin(String login){
       
        System.out.println();
        System.out.println(login);
        System.out.println();
       
       String jpql = "Select f from Atendente f where "
               + "(f.login = :l)";
       List <Atendente> list = em.createQuery(jpql,Atendente.class)
                  .setParameter("l", login)
                  .getResultList();
  
       if (list == null)
         return true;  
       //if (list != null && list.size()==0)
       //  return true;
       
       return false;     
   }
    
}
