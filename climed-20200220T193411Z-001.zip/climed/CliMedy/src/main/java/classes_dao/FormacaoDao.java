
package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Formacao;
import util.Conexao;

public class FormacaoDao {
    
    private EntityManager em;

    public FormacaoDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Formacao entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Formacao> getAll(){
        return em.createQuery("Select f from Formacao f",Formacao.class)
                .getResultList();
    }
    
    public Formacao getFormacao(Long codigo){
        return em.find(Formacao.class, codigo);
    }
    
    
    public Formacao remover(Long codigo){
        
        Formacao aux = getFormacao(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
}
