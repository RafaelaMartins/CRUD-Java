
package classes_dao;

import java.util.List;
import javax.persistence.EntityManager;
import modelo.Bairro;
import util.Conexao;

public class BairroDao {
    
    private EntityManager em;

    public BairroDao() {
       em = Conexao.getConexao();
    }

    public void salvar(Bairro entidade){
        
        em.getTransaction().begin();
        em.merge(entidade);
        em.getTransaction().commit();
    }

    public List<Bairro> getAll(){
        return em.createQuery("Select f from Bairro f",Bairro.class)
                .getResultList();
    }
    
    public Bairro getBairro(Long codigo){
        return em.find(Bairro.class, codigo);
    }
    
    
    public Bairro remover(Long codigo){
        
        Bairro aux = getBairro(codigo);
        
        em.getTransaction().begin();
        em.remove(aux);
        em.getTransaction().commit();
        
        return aux;
    }
    
}
