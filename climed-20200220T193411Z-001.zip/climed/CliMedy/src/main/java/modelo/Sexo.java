
package modelo;


public enum Sexo {
    FEMININO,
    MASCULINO,
    INDEFINIDO;
}
