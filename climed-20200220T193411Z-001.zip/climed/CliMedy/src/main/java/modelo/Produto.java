
package modelo;

import com.sun.istack.internal.NotNull;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Produto {
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE)    
    private Integer codigo;
    @NotNull
    private String nome;
    private String descricao;
    private String marca;
    private Double valor;
    private int estoque;
    
    @ManyToMany
    @JoinTable(name="ProdutoComposto",
            joinColumns = @JoinColumn(name="codProduto"),
            inverseJoinColumns = @JoinColumn(name="codComposto"))
    private List<Composto> compostos = new ArrayList<>();

    public Produto(Integer codigo, String nome, String descricao, String marca, Double valor, int estoque) {
        this.codigo = codigo;
        this.nome = nome;
        this.descricao = descricao;
        this.marca = marca;
        this.valor = valor;
        this.estoque = estoque;
    }

    public Produto() {
    }

    public Integer getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getMarca() {
        return marca;
    }

    public Double getValor() {
        return valor;
    }

    public int getEstoque() {
        return estoque;
    }

    public List<Composto> getCompostos() {
        return compostos;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public void setCompostos(List<Composto> compostos) {
        this.compostos = compostos;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.codigo;
        hash = 97 * hash + Objects.hashCode(this.nome);
        hash = 97 * hash + Objects.hashCode(this.descricao);
        hash = 97 * hash + Objects.hashCode(this.marca);
        hash = 97 * hash + Objects.hashCode(this.valor);
        hash = 97 * hash + this.estoque;
        hash = 97 * hash + Objects.hashCode(this.compostos);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Produto other = (Produto) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (this.estoque != other.estoque) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.marca, other.marca)) {
            return false;
        }
        if (!Objects.equals(this.valor, other.valor)) {
            return false;
        }
        if (!Objects.equals(this.compostos, other.compostos)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Produto{" + "codigo=" + codigo + ", nome=" + nome + ", descricao=" + descricao + ", marca=" + marca + ", valor=" + valor + ", estoque=" + estoque + ", compostos=" + compostos + '}';
    }
    
    
    
    
}
