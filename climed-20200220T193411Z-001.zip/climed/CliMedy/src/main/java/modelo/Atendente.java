
package modelo;

import com.sun.istack.internal.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@DiscriminatorValue("Atendente")

public class Atendente /*extends Pessoa*/ implements Serializable{
    
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    
    private Integer codigo;
    @NotNull
    private String nome;
    @Temporal(TemporalType.DATE)
    private Date dtNascimento;
    @Column(unique = true)
    private String cpf;
    @Enumerated(EnumType.STRING)
    private Sexo sexo;
    private String email; 
    private String tel_celular;
    private String tel_fixo;
    private String endereco;   
    private String cidade;    
    private String login;
    private String senha;     
    private Double salario;  
    private String cargo;  
    private String formacao; 
    
   
    public Atendente(Integer codigo, String nome, Date dtNascimento, String cpf, Sexo sexo, String email, String tel_celular, String tel_fixo, String endereco, String cidade, String login, String senha, Double salario, String cargo, String formacao) {
        this.codigo = codigo;
        this.nome = nome;
        this.dtNascimento = dtNascimento;
        this.cpf = cpf;
        this.sexo = sexo;
        this.email = email;
        this.tel_celular = tel_celular;
        this.tel_fixo = tel_fixo;
        this.endereco = endereco;
        this.cidade = cidade;
        this.login = login;
        this.senha = senha;
        this.salario = salario;
        this.cargo = cargo;
        this.formacao = formacao;
    }

    public Atendente() {
    }

    public String getLogin() {
        return login;
    }

    public String getSenha() {
        return senha;
    }

    public Double getSalario() {
        return salario;
    }

    public String getCargo() {
        return cargo;
    }     

    public Integer getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public Date getDtNascimento() {
        return dtNascimento;
    }

    public String getCpf() {
        return cpf;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public String getEmail() {
        return email;
    }

    public String getTel_celular() {
        return tel_celular;
    }

    public String getTel_fixo() {
        return tel_fixo;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getCidade() {
        return cidade;
    }

    public String getFormacao() {
        return formacao;
    }

    public void setFormacao(String formacao) {
        this.formacao = formacao;
    }   

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDtNascimento(Date dtNascimento) {
        this.dtNascimento = dtNascimento;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTel_celular(String tel_celular) {
        this.tel_celular = tel_celular;
    }

    public void setTel_fixo(String tel_fixo) {
        this.tel_fixo = tel_fixo;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }   
    
    
    public void setLogin(String login) {
        this.login = login;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.codigo);
        hash = 97 * hash + Objects.hashCode(this.nome);
        hash = 97 * hash + Objects.hashCode(this.dtNascimento);
        hash = 97 * hash + Objects.hashCode(this.cpf);
        hash = 97 * hash + Objects.hashCode(this.sexo);
        hash = 97 * hash + Objects.hashCode(this.email);
        hash = 97 * hash + Objects.hashCode(this.tel_celular);
        hash = 97 * hash + Objects.hashCode(this.tel_fixo);
        hash = 97 * hash + Objects.hashCode(this.endereco);
        hash = 97 * hash + Objects.hashCode(this.cidade);
        hash = 97 * hash + Objects.hashCode(this.login);
        hash = 97 * hash + Objects.hashCode(this.senha);
        hash = 97 * hash + Objects.hashCode(this.salario);
        hash = 97 * hash + Objects.hashCode(this.cargo);
        hash = 97 * hash + Objects.hashCode(this.formacao);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Atendente other = (Atendente) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.dtNascimento, other.dtNascimento)) {
            return false;
        }
        if (!Objects.equals(this.cpf, other.cpf)) {
            return false;
        }
        if (this.sexo != other.sexo) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.tel_celular, other.tel_celular)) {
            return false;
        }
        if (!Objects.equals(this.tel_fixo, other.tel_fixo)) {
            return false;
        }
        if (!Objects.equals(this.endereco, other.endereco)) {
            return false;
        }
        if (!Objects.equals(this.cidade, other.cidade)) {
            return false;
        }
        if (!Objects.equals(this.login, other.login)) {
            return false;
        }
        if (!Objects.equals(this.senha, other.senha)) {
            return false;
        }
        if (!Objects.equals(this.salario, other.salario)) {
            return false;
        }
        if (!Objects.equals(this.cargo, other.cargo)) {
            return false;
        }
        if (!Objects.equals(this.formacao, other.formacao)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Atendente{" + "codigo=" + codigo + ", nome=" + nome + ", dtNascimento=" + dtNascimento + ", cpf=" + cpf + ", sexo=" + sexo + ", email=" + email + ", tel_celular=" + tel_celular + ", tel_fixo=" + tel_fixo + ", endereco=" + endereco + ", cidade=" + cidade + ", login=" + login + ", senha=" + senha + ", salario=" + salario + ", cargo=" + cargo + ", formacao=" + formacao + '}';
    }     
    
            
}
