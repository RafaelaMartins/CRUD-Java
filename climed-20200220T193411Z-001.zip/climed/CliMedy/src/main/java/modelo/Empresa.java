
package modelo;

import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import modelo.Administrador;

@Entity
public class Empresa {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
  
    private Integer codigo;
    private String rasaoSocial;
    private String nomeFantasia;
    private String cnpj;
    private String ie;
    private String telefone;   
    private String contato; // email ou site;
    private String endereco;
    //@OneToOne(cascade = CascadeType.ALL)
    //@JoinColumn(name="codAdm")
    //private Administrador adm;

    public Empresa(String rasaoSocial, String nomeFantasia, String cnpj, String ie, String telefone, Integer codigo, String contato, String endereco) {
        this.rasaoSocial = rasaoSocial;
        this.nomeFantasia = nomeFantasia;
        this.cnpj = cnpj;
        this.ie = ie;
        this.telefone = telefone;
        //this.adm = adm;
        this.codigo = codigo;
        this.contato = contato;
        this.endereco = endereco;
    }

    public Empresa() {
    }

    public String getRasaoSocial() {
        return rasaoSocial;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public String getCnpj() {
        return cnpj;
    }

    public String getIe() {
        return ie;
    }

    public String getTelefone() {
        return telefone;
    }

    /*
    public Administrador getAdm() {
        return adm;
    }
    */
    
    public Integer getCodigo() {
        return codigo;
    }

    public String getContato() {
        return contato;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }    

    public void setContato(String contato) {
        this.contato = contato;
    }   
    
    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }        

    public void setRasaoSocial(String rasaoSocial) {
        this.rasaoSocial = rasaoSocial;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public void setIe(String ie) {
        this.ie = ie;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
 
    /*
    public void setAdm(Administrador adm) {
        this.adm = adm;
    }
    */

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 41 * hash + Objects.hashCode(this.codigo);
        hash = 41 * hash + Objects.hashCode(this.rasaoSocial);
        hash = 41 * hash + Objects.hashCode(this.nomeFantasia);
        hash = 41 * hash + Objects.hashCode(this.cnpj);
        hash = 41 * hash + Objects.hashCode(this.ie);
        hash = 41 * hash + Objects.hashCode(this.telefone);
        hash = 41 * hash + Objects.hashCode(this.contato);
        hash = 41 * hash + Objects.hashCode(this.endereco);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Empresa other = (Empresa) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.rasaoSocial, other.rasaoSocial)) {
            return false;
        }
        if (!Objects.equals(this.nomeFantasia, other.nomeFantasia)) {
            return false;
        }
        if (!Objects.equals(this.cnpj, other.cnpj)) {
            return false;
        }
        if (!Objects.equals(this.ie, other.ie)) {
            return false;
        }
        if (!Objects.equals(this.telefone, other.telefone)) {
            return false;
        }
        if (!Objects.equals(this.contato, other.contato)) {
            return false;
        }
        if (!Objects.equals(this.endereco, other.endereco)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Empresa{" + "codigo=" + codigo + ", rasaoSocial=" + rasaoSocial + ", nomeFantasia=" + nomeFantasia + ", cnpj=" + cnpj + ", ie=" + ie + ", telefone=" + telefone + ", contato=" + contato + ", endereco=" + endereco + '}';
    }       
           
}
