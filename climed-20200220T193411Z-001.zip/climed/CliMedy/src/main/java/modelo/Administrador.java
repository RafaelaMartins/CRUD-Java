
package modelo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@DiscriminatorValue("Administrador")

public class Administrador extends Pessoa implements Serializable{
    
    private String login = "admin";
    private String senha = "admin1234";

    public Administrador(String login, String senha) {
        this.login=login;
        this.senha=senha;
    }

    public Administrador() {
    }

    public String getLogin() {
        return login;
    }

    public String getSenha() {
        return senha;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }   

    @Override
    public String toString() {
        return super.toString()+"Administrador{" + "login=" + login + ", senha=" + senha + '}';
    }
    
    
}
