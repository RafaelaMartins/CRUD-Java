
package modelo;

import java.util.Date;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
public class Agenda {
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE)
    
    private Integer codigo;
    @Temporal(TemporalType.DATE)
    private Date data;
    @Temporal(TemporalType.TIMESTAMP)
    private Date h_inicio;
    @Temporal(TemporalType.TIMESTAMP)
    private Date h_fim;
    private String status; //agendado, realizado, cancelado
    
    @ManyToOne
    @JoinColumn(name="codAtendente")
    private Atendente atendente;
    
    @ManyToOne
    @JoinColumn(name="codPaciente")
    private Paciente paciente;
    
    @ManyToOne
    @JoinColumn(name="codProcedimento")
    private Procedimento Procedimento;   

    public Agenda(Date data, Date h_inicio, Date h_fim, Atendente atendente, Paciente paciente, Procedimento Procedimento, String status, Integer codigo) {
        this.data = data;
        this.h_inicio = h_inicio;
        this.h_fim = h_fim;
        this.atendente = atendente;
        this.paciente = paciente;
        this.Procedimento = Procedimento;
        this.status = status;
        this.codigo = codigo;
    }

    public Agenda() {
    }

    public Date getData() {
        return data;
    }

    public Date getH_inicio() {
        return h_inicio;
    }

    public Date getH_fim() {
        return h_fim;
    }

    public Atendente getAtendente() {
        return atendente;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public Procedimento getProcedimento() {
        return Procedimento;
    }

    public String getStatus() {
        return status;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }   
    
    public void setData(Date data) {
        this.data = data;
    }

    public void setH_inicio(Date h_inicio) {
        this.h_inicio = h_inicio;
    }

    public void setH_fim(Date h_fim) {
        this.h_fim = h_fim;
    }

    public void setAtendente(Atendente atendente) {
        this.atendente = atendente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public void setProcedimento(Procedimento Procedimento) {
        this.Procedimento = Procedimento;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + this.codigo;
        hash = 89 * hash + Objects.hashCode(this.data);
        hash = 89 * hash + Objects.hashCode(this.h_inicio);
        hash = 89 * hash + Objects.hashCode(this.h_fim);
        hash = 89 * hash + Objects.hashCode(this.atendente);
        hash = 89 * hash + Objects.hashCode(this.paciente);
        hash = 89 * hash + Objects.hashCode(this.Procedimento);
        hash = 89 * hash + Objects.hashCode(this.status);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Agenda other = (Agenda) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (!Objects.equals(this.status, other.status)) {
            return false;
        }
        if (!Objects.equals(this.data, other.data)) {
            return false;
        }
        if (!Objects.equals(this.h_inicio, other.h_inicio)) {
            return false;
        }
        if (!Objects.equals(this.h_fim, other.h_fim)) {
            return false;
        }
        if (!Objects.equals(this.atendente, other.atendente)) {
            return false;
        }
        if (!Objects.equals(this.paciente, other.paciente)) {
            return false;
        }
        if (!Objects.equals(this.Procedimento, other.Procedimento)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Agenda{" + "codigo=" + codigo + ", data=" + data + ", h_inicio=" + h_inicio + ", h_fim=" + h_fim + ", atendente=" + atendente + ", paciente=" + paciente + ", Procedimento=" + Procedimento + ", status=" + status + '}';
    }    
      
   
}
