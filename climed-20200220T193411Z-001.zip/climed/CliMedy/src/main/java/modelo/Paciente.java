
package modelo;

import com.sun.istack.internal.NotNull;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@DiscriminatorValue("Paciente")

public class Paciente /*extends Pessoa*/{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    
    private Integer codigo;
    @NotNull
    private String nome;
    @Temporal(TemporalType.DATE)
    private Date dtNascimento;
    @Column(unique = true)
    private String cpf;
    @Enumerated(EnumType.STRING)
    private Sexo sexo;
    private String email; 
    private String tel_celular;
    private String tel_fixo;
    private String endereco;   
    private String cidade;    
    private List<Composto>alergias = new ArrayList<>();
    @ManyToMany
    @JoinTable(name="Procedimento",
            joinColumns = @JoinColumn(name="codTratamento"),
            inverseJoinColumns=@JoinColumn(name="codTratamento"))
    private List<Procedimento> tratamentos = new ArrayList<>();

    
    
    public Paciente() {
    }

    public Paciente(Integer codigo, String nome, Date dtNascimento, String cpf, Sexo sexo, String email, String tel_celular, String tel_fixo, String endereco, String cidade) {
        this.codigo = codigo;
        this.nome = nome;
        this.dtNascimento = dtNascimento;
        this.cpf = cpf;
        this.sexo = sexo;
        this.email = email;
        this.tel_celular = tel_celular;
        this.tel_fixo = tel_fixo;
        this.endereco = endereco;
        this.cidade = cidade;
    }   
        
    /*
    public Paciente(List<String> alergias, List<Procedimento> tratamentos) {
        this.alergias=alergias;
        this.tratamentos=tratamentos;
    }
    */

    public List<Composto> getAlergias() {
        return alergias;
    }

    public List<Procedimento> getTratamentos() {
        return tratamentos;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public Date getDtNascimento() {
        return dtNascimento;
    }

    public String getCpf() {
        return cpf;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public String getEmail() {
        return email;
    }

    public String getTel_celular() {
        return tel_celular;
    }

    public String getTel_fixo() {
        return tel_fixo;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDtNascimento(Date dtNascimento) {
        this.dtNascimento = dtNascimento;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTel_celular(String tel_celular) {
        this.tel_celular = tel_celular;
    }

    public void setTel_fixo(String tel_fixo) {
        this.tel_fixo = tel_fixo;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }      

    public void setAlergias(List<Composto> alergias) {
        this.alergias = alergias;
    }

    public void setTratamentos(List<Procedimento> tratamentos) {
        this.tratamentos = tratamentos;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + Objects.hashCode(this.codigo);
        hash = 79 * hash + Objects.hashCode(this.nome);
        hash = 79 * hash + Objects.hashCode(this.dtNascimento);
        hash = 79 * hash + Objects.hashCode(this.cpf);
        hash = 79 * hash + Objects.hashCode(this.sexo);
        hash = 79 * hash + Objects.hashCode(this.email);
        hash = 79 * hash + Objects.hashCode(this.tel_celular);
        hash = 79 * hash + Objects.hashCode(this.tel_fixo);
        hash = 79 * hash + Objects.hashCode(this.endereco);
        hash = 79 * hash + Objects.hashCode(this.cidade);
        hash = 79 * hash + Objects.hashCode(this.alergias);
        hash = 79 * hash + Objects.hashCode(this.tratamentos);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Paciente other = (Paciente) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.dtNascimento, other.dtNascimento)) {
            return false;
        }
        if (!Objects.equals(this.cpf, other.cpf)) {
            return false;
        }
        if (this.sexo != other.sexo) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.tel_celular, other.tel_celular)) {
            return false;
        }
        if (!Objects.equals(this.tel_fixo, other.tel_fixo)) {
            return false;
        }
        if (!Objects.equals(this.endereco, other.endereco)) {
            return false;
        }
        if (!Objects.equals(this.cidade, other.cidade)) {
            return false;
        }
        if (!Objects.equals(this.alergias, other.alergias)) {
            return false;
        }
        if (!Objects.equals(this.tratamentos, other.tratamentos)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Paciente{" + "codigo=" + codigo + ", nome=" + nome + ", dtNascimento=" + dtNascimento + ", cpf=" + cpf + ", sexo=" + sexo + ", email=" + email + ", tel_celular=" + tel_celular + ", tel_fixo=" + tel_fixo + ", endereco=" + endereco + ", cidade=" + cidade + ", alergias=" + alergias + ", tratamentos=" + tratamentos + '}';
    }  
    
}
