
package modelo;

import com.sun.istack.internal.NotNull;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Procedimento {
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE)
    
    private Integer codigo;
    private String nome;
    private String descricao;
    private Double valor;   
    
    @ManyToMany
    @JoinTable(name="ProcedimentoEquipamento",
            joinColumns = @JoinColumn(name="codProcedimento"),
            inverseJoinColumns=@JoinColumn(name="codEquipamento"))
    private List<Equipamento> equipamentos = new ArrayList<>();
    
    @ManyToMany
    @JoinTable(name="ProcedimentoProduto",
            joinColumns = @JoinColumn(name="codProcedimento"),
            inverseJoinColumns=@JoinColumn(name="codProduto"))
    private List<Produto> produtos = new ArrayList<>();

    public Procedimento(Integer codigo, String nome, String descricao, Double valor, List<Produto> produtos) {
        this.codigo = codigo;
        this.nome = nome;
        this.descricao = descricao;
        this.valor = valor;        
        this.produtos = produtos;
    }

    public Procedimento() {
    }

    public Integer getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public Double getValor() {
        return valor;
    }     

    public List<Produto> getProdutos() {
        return produtos;
    }

    public List<Equipamento> getEquipamentos() {
        return equipamentos;
    }

    public void setEquipamentos(List<Equipamento> equipamentos) {
        this.equipamentos = equipamentos;
    }   

    public void setProdutos(List<Produto> produtos) {
        this.produtos = produtos;
    }   
    
    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }        

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 73 * hash + this.codigo;
        hash = 73 * hash + Objects.hashCode(this.nome);
        hash = 73 * hash + Objects.hashCode(this.descricao);
        hash = 73 * hash + Objects.hashCode(this.valor);
        hash = 73 * hash + Objects.hashCode(this.equipamentos);
        hash = 73 * hash + Objects.hashCode(this.produtos);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Procedimento other = (Procedimento) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.valor, other.valor)) {
            return false;
        }
        if (!Objects.equals(this.equipamentos, other.equipamentos)) {
            return false;
        }
        if (!Objects.equals(this.produtos, other.produtos)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Procedimento{" + "codigo=" + codigo + ", nome=" + nome + ", descricao=" + descricao + ", valor=" + valor + ", equipamentos=" + equipamentos + ", produtos=" + produtos + '}';
    }
     
    
}
