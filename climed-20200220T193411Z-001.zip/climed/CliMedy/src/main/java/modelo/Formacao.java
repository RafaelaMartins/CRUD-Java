
package modelo;

import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Formacao {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    
    private int codigo;
    private String curso;
    private String universidade;  

    public Formacao(int codigo, String curso, String universidade) {
        this.codigo = codigo;
        this.curso = curso;
        this.universidade = universidade;
    }

    public Formacao() {
    }

    public int getCodigo() {
        return codigo;
    }

    public String getCurso() {
        return curso;
    }

    public String getUniversidade() {
        return universidade;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public void setUniversidade(String universidade) {
        this.universidade = universidade;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + this.codigo;
        hash = 23 * hash + Objects.hashCode(this.curso);
        hash = 23 * hash + Objects.hashCode(this.universidade);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Formacao other = (Formacao) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (!Objects.equals(this.curso, other.curso)) {
            return false;
        }
        if (!Objects.equals(this.universidade, other.universidade)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Formacao{" + "codigo=" + codigo + ", curso=" + curso + ", universidade=" + universidade + '}';
    }
    
    
    
}
